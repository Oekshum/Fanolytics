﻿using Quintessential;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fanolytics
{
    internal static class Atoms
    {
        public static AtomType FanoA, FanoB, FanoC, FanoD, FanoE, FanoF, FanoG;
        public static AtomType[] FanoAtoms = { FanoA, FanoB, FanoC, FanoD, FanoE, FanoF, FanoG };
        public static void AddAtomTypes ()
        {
            FanoA = Brimstone.API.CreateNormalAtom(21, "Fanolytics", "Fano A", class_238.field_1989.field_81.field_598, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);
            FanoB = Brimstone.API.CreateNormalAtom(22, "Fanolytics", "Fano B", class_238.field_1989.field_81.field_613.field_626, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);
            FanoC = Brimstone.API.CreateNormalAtom(23, "Fanolytics", "Fano C", class_238.field_1989.field_81.field_613.field_622, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);
            FanoD = Brimstone.API.CreateNormalAtom(24, "Fanolytics", "Fano D", class_238.field_1989.field_81.field_598, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);
            FanoE = Brimstone.API.CreateNormalAtom(25, "Fanolytics", "Fano E", class_238.field_1989.field_81.field_598, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);
            FanoF = Brimstone.API.CreateNormalAtom(26, "Fanolytics", "Fano F", class_238.field_1989.field_81.field_598, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);
            FanoG = Brimstone.API.CreateNormalAtom(27, "Fanolytics", "Fano G", class_238.field_1989.field_81.field_598, class_238.field_1989.field_81.field_596, class_238.field_1989.field_81.field_599, class_238.field_1989.field_81.field_597);

            QApi.AddAtomType(FanoA);
            QApi.AddAtomType(FanoB);
            QApi.AddAtomType(FanoC);
            QApi.AddAtomType(FanoD);
            QApi.AddAtomType(FanoE);
            QApi.AddAtomType(FanoF);
            QApi.AddAtomType(FanoG);
        }
    }
}
